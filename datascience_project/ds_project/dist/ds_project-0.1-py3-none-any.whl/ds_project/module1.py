# ds_project/module1.py
def hello_world():
    return "Hello, world! My name is Sumit@@@"

def main():
    print(hello_world())

if __name__ == "__main__":
    main()
